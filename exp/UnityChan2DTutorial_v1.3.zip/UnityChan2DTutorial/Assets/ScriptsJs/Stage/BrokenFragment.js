#pragma strict
//================
// Block Fragment
// 方塊碎片
//================

function Die(){
  Destroy(gameObject) ;
}