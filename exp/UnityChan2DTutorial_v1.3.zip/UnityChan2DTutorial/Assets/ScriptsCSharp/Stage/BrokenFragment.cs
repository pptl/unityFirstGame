﻿//================
// Block Fragment
// 方塊碎片
//================
using UnityEngine;
using System.Collections;

public class BrokenFragment : MonoBehaviour {

	void Die(){
		Destroy(gameObject) ;
	}
}
